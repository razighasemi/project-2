﻿namespace School_Project
{
    partial class frmStudent_Subjects
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.student_by_idBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDBDataSet = new School_Project.SchoolDBDataSet();
            this.fillbyIdToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.param1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.fillbyIdToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.student_by_idDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.student_by_idTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.Student_by_idTableAdapter();
            this.tableAdapterManager = new School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager();
            this.studentAndSubjectsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentAndSubjectsTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.studentAndSubjectsTableAdapter();
            this.studentAndSubjectsDataGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).BeginInit();
            this.fillbyIdToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentAndSubjectsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentAndSubjectsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // student_by_idBindingSource
            // 
            this.student_by_idBindingSource.DataMember = "Student_by_id";
            this.student_by_idBindingSource.DataSource = this.schoolDBDataSet;
            // 
            // schoolDBDataSet
            // 
            this.schoolDBDataSet.DataSetName = "SchoolDBDataSet";
            this.schoolDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fillbyIdToolStrip
            // 
            this.fillbyIdToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillbyIdToolStrip.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillbyIdToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fillbyIdToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel,
            this.toolStripSeparator2,
            this.param1ToolStripTextBox,
            this.toolStripSeparator1,
            this.fillbyIdToolStripButton});
            this.fillbyIdToolStrip.Location = new System.Drawing.Point(263, 38);
            this.fillbyIdToolStrip.Name = "fillbyIdToolStrip";
            this.fillbyIdToolStrip.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.fillbyIdToolStrip.Size = new System.Drawing.Size(274, 28);
            this.fillbyIdToolStrip.TabIndex = 1;
            this.fillbyIdToolStrip.Text = "fillbyIdToolStrip";
            // 
            // param1ToolStripLabel
            // 
            this.param1ToolStripLabel.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.param1ToolStripLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.param1ToolStripLabel.Name = "param1ToolStripLabel";
            this.param1ToolStripLabel.Size = new System.Drawing.Size(90, 25);
            this.param1ToolStripLabel.Text = "Student_Id: ";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 28);
            // 
            // param1ToolStripTextBox
            // 
            this.param1ToolStripTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.param1ToolStripTextBox.Name = "param1ToolStripTextBox";
            this.param1ToolStripTextBox.Size = new System.Drawing.Size(76, 28);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // fillbyIdToolStripButton
            // 
            this.fillbyIdToolStripButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.fillbyIdToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillbyIdToolStripButton.ForeColor = System.Drawing.SystemColors.Desktop;
            this.fillbyIdToolStripButton.Name = "fillbyIdToolStripButton";
            this.fillbyIdToolStripButton.Size = new System.Drawing.Size(44, 25);
            this.fillbyIdToolStripButton.Text = "Find";
            this.fillbyIdToolStripButton.Click += new System.EventHandler(this.fillbyIdToolStripButton_Click);
            // 
            // student_by_idDataGridView
            // 
            this.student_by_idDataGridView.AllowUserToAddRows = false;
            this.student_by_idDataGridView.AllowUserToDeleteRows = false;
            this.student_by_idDataGridView.AutoGenerateColumns = false;
            this.student_by_idDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.student_by_idDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.student_by_idDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewCheckBoxColumn1});
            this.student_by_idDataGridView.DataSource = this.student_by_idBindingSource;
            this.student_by_idDataGridView.Location = new System.Drawing.Point(9, 145);
            this.student_by_idDataGridView.Name = "student_by_idDataGridView";
            this.student_by_idDataGridView.ReadOnly = true;
            this.student_by_idDataGridView.RowHeadersWidth = 51;
            this.student_by_idDataGridView.RowTemplate.Height = 24;
            this.student_by_idDataGridView.Size = new System.Drawing.Size(812, 95);
            this.student_by_idDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "StudentId";
            this.dataGridViewTextBoxColumn1.HeaderText = "StudentId";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "StudentName";
            this.dataGridViewTextBoxColumn2.HeaderText = "StudentName";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "StudentTel";
            this.dataGridViewTextBoxColumn3.HeaderText = "StudentTel";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "StudentAddress";
            this.dataGridViewTextBoxColumn4.HeaderText = "StudentAddress";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "StudentEmail";
            this.dataGridViewTextBoxColumn5.HeaderText = "StudentEmail";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "StudentGender";
            this.dataGridViewCheckBoxColumn1.HeaderText = "StudentGender";
            this.dataGridViewCheckBoxColumn1.MinimumWidth = 6;
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.Width = 125;
            // 
            // student_by_idTableAdapter
            // 
            this.student_by_idTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Student_by_idTableAdapter = this.student_by_idTableAdapter;
            this.tableAdapterManager.Student_SubjectTableAdapter = null;
            this.tableAdapterManager.StudentTableAdapter = null;
            this.tableAdapterManager.Subject_TeacherTableAdapter = null;
            this.tableAdapterManager.SubjectTableAdapter = null;
            this.tableAdapterManager.TeacherTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // studentAndSubjectsBindingSource
            // 
            this.studentAndSubjectsBindingSource.DataMember = "studentAndSubjects";
            this.studentAndSubjectsBindingSource.DataSource = this.schoolDBDataSet;
            // 
            // studentAndSubjectsTableAdapter
            // 
            this.studentAndSubjectsTableAdapter.ClearBeforeFill = true;
            // 
            // studentAndSubjectsDataGridView
            // 
            this.studentAndSubjectsDataGridView.AllowUserToAddRows = false;
            this.studentAndSubjectsDataGridView.AllowUserToDeleteRows = false;
            this.studentAndSubjectsDataGridView.AutoGenerateColumns = false;
            this.studentAndSubjectsDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.studentAndSubjectsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentAndSubjectsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.studentAndSubjectsDataGridView.DataSource = this.studentAndSubjectsBindingSource;
            this.studentAndSubjectsDataGridView.Location = new System.Drawing.Point(141, 294);
            this.studentAndSubjectsDataGridView.Name = "studentAndSubjectsDataGridView";
            this.studentAndSubjectsDataGridView.ReadOnly = true;
            this.studentAndSubjectsDataGridView.RowHeadersWidth = 51;
            this.studentAndSubjectsDataGridView.RowTemplate.Height = 24;
            this.studentAndSubjectsDataGridView.Size = new System.Drawing.Size(632, 262);
            this.studentAndSubjectsDataGridView.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Student Information:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 294);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Student Subjects:";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "SubjectId";
            this.dataGridViewTextBoxColumn11.HeaderText = "SubjectId";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 125;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "SubjectName";
            this.dataGridViewTextBoxColumn12.HeaderText = "SubjectName";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 125;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "SubjectUnit";
            this.dataGridViewTextBoxColumn13.HeaderText = "SubjectUnit";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 125;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "SubjectDescription";
            this.dataGridViewTextBoxColumn14.HeaderText = "SubjectDescription";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 200;
            // 
            // frmStudent_Subjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(830, 569);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.studentAndSubjectsDataGridView);
            this.Controls.Add(this.student_by_idDataGridView);
            this.Controls.Add(this.fillbyIdToolStrip);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmStudent_Subjects";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmStudent_Subjects";
            this.Load += new System.EventHandler(this.frmStudent_Subjects_Load);
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).EndInit();
            this.fillbyIdToolStrip.ResumeLayout(false);
            this.fillbyIdToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentAndSubjectsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentAndSubjectsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDBDataSet schoolDBDataSet;
        private System.Windows.Forms.BindingSource student_by_idBindingSource;
        private SchoolDBDataSetTableAdapters.Student_by_idTableAdapter student_by_idTableAdapter;
        private SchoolDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ToolStrip fillbyIdToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillbyIdToolStripButton;
        private System.Windows.Forms.DataGridView student_by_idDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.BindingSource studentAndSubjectsBindingSource;
        private SchoolDBDataSetTableAdapters.studentAndSubjectsTableAdapter studentAndSubjectsTableAdapter;
        private System.Windows.Forms.DataGridView studentAndSubjectsDataGridView;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
    }
}