﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Project
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmStudent frmStudent = new frmStudent();
            frmStudent.ShowDialog(this);
        }

        private void studentsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmTeacher frmTeacher = new frmTeacher();
            frmTeacher.ShowDialog(this);
        }

        private void subjectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSubject frmSubject = new frmSubject();
            frmSubject.ShowDialog(this);
        }

        private void studentsSubjectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmStudent_Subjects frmStudent_Subjects = new frmStudent_Subjects();
            frmStudent_Subjects.ShowDialog(this);
        }

        private void teachersSubjectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTeacher_Subjects frmTeacher_Subjects = new frmTeacher_Subjects();
            frmTeacher_Subjects.ShowDialog(this);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void studentsTeachersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmStudent_Teachers frmStudent_Teachers = new frmStudent_Teachers();
            frmStudent_Teachers.ShowDialog(this);
        }

        
        private void teachersStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTeacher_Students frmTS = new frmTeacher_Students();
            frmTS.ShowDialog(this);
        }
    }
}
