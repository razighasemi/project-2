﻿namespace School_Project
{
    partial class frmStudent_Teachers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.fillbyIdToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillbyIdToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.student_by_idDataGridView = new System.Windows.Forms.DataGridView();
            this.teacher_by_stIdDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.teacher_by_stIdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDBDataSet = new School_Project.SchoolDBDataSet();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.student_by_idBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_idTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.Student_by_idTableAdapter();
            this.tableAdapterManager = new School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager();
            this.teacher_by_stIdTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.Teacher_by_stIdTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fillbyIdToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_stIdDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_stIdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // fillbyIdToolStrip
            // 
            this.fillbyIdToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillbyIdToolStrip.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillbyIdToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel,
            this.param1ToolStripTextBox,
            this.fillbyIdToolStripButton});
            this.fillbyIdToolStrip.Location = new System.Drawing.Point(180, 37);
            this.fillbyIdToolStrip.Name = "fillbyIdToolStrip";
            this.fillbyIdToolStrip.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.fillbyIdToolStrip.Size = new System.Drawing.Size(321, 28);
            this.fillbyIdToolStrip.TabIndex = 1;
            this.fillbyIdToolStrip.Text = "fillbyIdToolStrip";
            // 
            // param1ToolStripLabel
            // 
            this.param1ToolStripLabel.Name = "param1ToolStripLabel";
            this.param1ToolStripLabel.Size = new System.Drawing.Size(83, 25);
            this.param1ToolStripLabel.Text = "Student Id:";
            // 
            // param1ToolStripTextBox
            // 
            this.param1ToolStripTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.param1ToolStripTextBox.Name = "param1ToolStripTextBox";
            this.param1ToolStripTextBox.Size = new System.Drawing.Size(148, 28);
            // 
            // fillbyIdToolStripButton
            // 
            this.fillbyIdToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillbyIdToolStripButton.Name = "fillbyIdToolStripButton";
            this.fillbyIdToolStripButton.Size = new System.Drawing.Size(44, 25);
            this.fillbyIdToolStripButton.Text = "Find";
            this.fillbyIdToolStripButton.Click += new System.EventHandler(this.fillbyIdToolStripButton_Click);
            // 
            // student_by_idDataGridView
            // 
            this.student_by_idDataGridView.AllowUserToAddRows = false;
            this.student_by_idDataGridView.AllowUserToDeleteRows = false;
            this.student_by_idDataGridView.AutoGenerateColumns = false;
            this.student_by_idDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.student_by_idDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.student_by_idDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewCheckBoxColumn1});
            this.student_by_idDataGridView.DataSource = this.student_by_idBindingSource;
            this.student_by_idDataGridView.Location = new System.Drawing.Point(14, 101);
            this.student_by_idDataGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.student_by_idDataGridView.Name = "student_by_idDataGridView";
            this.student_by_idDataGridView.ReadOnly = true;
            this.student_by_idDataGridView.Size = new System.Drawing.Size(656, 136);
            this.student_by_idDataGridView.TabIndex = 2;
            // 
            // teacher_by_stIdDataGridView
            // 
            this.teacher_by_stIdDataGridView.AllowUserToAddRows = false;
            this.teacher_by_stIdDataGridView.AllowUserToDeleteRows = false;
            this.teacher_by_stIdDataGridView.AutoGenerateColumns = false;
            this.teacher_by_stIdDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.teacher_by_stIdDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.teacher_by_stIdDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewCheckBoxColumn2});
            this.teacher_by_stIdDataGridView.DataSource = this.teacher_by_stIdBindingSource;
            this.teacher_by_stIdDataGridView.Location = new System.Drawing.Point(14, 283);
            this.teacher_by_stIdDataGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.teacher_by_stIdDataGridView.Name = "teacher_by_stIdDataGridView";
            this.teacher_by_stIdDataGridView.ReadOnly = true;
            this.teacher_by_stIdDataGridView.Size = new System.Drawing.Size(656, 257);
            this.teacher_by_stIdDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "TeacherId";
            this.dataGridViewTextBoxColumn6.HeaderText = "TeacherId";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "TeacherName";
            this.dataGridViewTextBoxColumn7.HeaderText = "TeacherName";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "TeacherTel";
            this.dataGridViewTextBoxColumn8.HeaderText = "TeacherTel";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "TeacherAddress";
            this.dataGridViewTextBoxColumn9.HeaderText = "TeacherAddress";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "TeacherEmail";
            this.dataGridViewTextBoxColumn10.HeaderText = "TeacherEmail";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "TeacherGender";
            this.dataGridViewCheckBoxColumn2.HeaderText = "TeacherGender";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            // 
            // teacher_by_stIdBindingSource
            // 
            this.teacher_by_stIdBindingSource.DataMember = "Teacher_by_stId";
            this.teacher_by_stIdBindingSource.DataSource = this.schoolDBDataSet;
            // 
            // schoolDBDataSet
            // 
            this.schoolDBDataSet.DataSetName = "SchoolDBDataSet";
            this.schoolDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "StudentId";
            this.dataGridViewTextBoxColumn1.HeaderText = "StudentId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "StudentName";
            this.dataGridViewTextBoxColumn2.HeaderText = "StudentName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "StudentTel";
            this.dataGridViewTextBoxColumn3.HeaderText = "StudentTel";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "StudentAddress";
            this.dataGridViewTextBoxColumn4.HeaderText = "StudentAddress";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "StudentEmail";
            this.dataGridViewTextBoxColumn5.HeaderText = "StudentEmail";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "StudentGender";
            this.dataGridViewCheckBoxColumn1.HeaderText = "StudentGender";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // student_by_idBindingSource
            // 
            this.student_by_idBindingSource.DataMember = "Student_by_id";
            this.student_by_idBindingSource.DataSource = this.schoolDBDataSet;
            // 
            // student_by_idTableAdapter
            // 
            this.student_by_idTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Student_by_idTableAdapter = this.student_by_idTableAdapter;
            this.tableAdapterManager.Student_SubjectTableAdapter = null;
            this.tableAdapterManager.StudentTableAdapter = null;
            this.tableAdapterManager.Subject_TeacherTableAdapter = null;
            this.tableAdapterManager.SubjectTableAdapter = null;
            this.tableAdapterManager.TeacherTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // teacher_by_stIdTableAdapter
            // 
            this.teacher_by_stIdTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Student Information:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Teachers Information:";
            // 
            // frmStudent_Teachers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(684, 557);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.teacher_by_stIdDataGridView);
            this.Controls.Add(this.student_by_idDataGridView);
            this.Controls.Add(this.fillbyIdToolStrip);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmStudent_Teachers";
            this.Text = "student_teachers";
            this.fillbyIdToolStrip.ResumeLayout(false);
            this.fillbyIdToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_stIdDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_stIdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_idBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDBDataSet schoolDBDataSet;
        private System.Windows.Forms.BindingSource student_by_idBindingSource;
        private SchoolDBDataSetTableAdapters.Student_by_idTableAdapter student_by_idTableAdapter;
        private SchoolDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ToolStrip fillbyIdToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillbyIdToolStripButton;
        private System.Windows.Forms.DataGridView student_by_idDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.BindingSource teacher_by_stIdBindingSource;
        private SchoolDBDataSetTableAdapters.Teacher_by_stIdTableAdapter teacher_by_stIdTableAdapter;
        private System.Windows.Forms.DataGridView teacher_by_stIdDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}