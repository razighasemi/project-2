﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Project
{
    public partial class frmTeacher_Subjects : Form
    {
        public frmTeacher_Subjects()
        {
            InitializeComponent();
        }

        private void fill_teacher_by_idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.teacher_by_idTableAdapter.Fill_teacher_by_id(this.schoolDBDataSet.Teacher_by_id, ((int)(System.Convert.ChangeType(param1ToolStripTextBox.Text, typeof(int)))));
                this.teacherAndSubjectsTableAdapter.Fillby_teacher_id(this.schoolDBDataSet.TeacherAndSubjects, ((int)(System.Convert.ChangeType(param1ToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }


    }
}
