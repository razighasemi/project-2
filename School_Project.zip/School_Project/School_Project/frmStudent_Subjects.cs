﻿using School_Project.SchoolDBDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Project
{
    public partial class frmStudent_Subjects : Form
    {
        public frmStudent_Subjects()
        {
            InitializeComponent();
        }

       

        private void frmStudent_Subjects_Load(object sender, EventArgs e)
        {
        }



        

        private void student_by_idBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.student_by_idBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.schoolDBDataSet);

        }

        private void fillbyIdToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.student_by_idTableAdapter.FillbyId(this.schoolDBDataSet.Student_by_id, ((int)(System.Convert.ChangeType(param1ToolStripTextBox.Text, typeof(int)))));
                this.studentAndSubjectsTableAdapter.Fillby_St_Id(this.schoolDBDataSet.studentAndSubjects, ((int)(System.Convert.ChangeType(param1ToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

       
    }
}
