﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Project
{
    public partial class frmTeacher : Form
    {
        public frmTeacher()
        {
            InitializeComponent();
        }

        private void teacherBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.teacherBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.schoolDBDataSet);

        }

        private void frmTeacher_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDBDataSet.Teacher' table. You can move, or remove it, as needed.
            this.teacherTableAdapter.Fill(this.schoolDBDataSet.Teacher);

        }

        private void teacherGenderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.teacherGenderCheckBox.CheckState == CheckState.Checked)
                teacherGenderCheckBox.Text = "Male";
            else if (this.teacherGenderCheckBox.CheckState == CheckState.Unchecked)
                teacherGenderCheckBox.Text = "Female";
            else
                teacherGenderCheckBox.Text = "?";
        }
    }
}
