﻿namespace School_Project
{
    partial class frmTeacher_Students
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.schoolDBDataSet = new School_Project.SchoolDBDataSet();
            this.teacher_by_idBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacher_by_idTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.Teacher_by_idTableAdapter();
            this.tableAdapterManager = new School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager();
            this.fill_teacher_by_idToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fill_teacher_by_idToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.teacher_by_idDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.student_by_teacherIdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_teacherIdTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.Student_by_teacherIdTableAdapter();
            this.student_by_teacherIdBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_teacherIdBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_teacherIdBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_teacherIdBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_teacherIdBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.student_by_teacherIdDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idBindingSource)).BeginInit();
            this.fill_teacher_by_idToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // schoolDBDataSet
            // 
            this.schoolDBDataSet.DataSetName = "SchoolDBDataSet";
            this.schoolDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // teacher_by_idBindingSource
            // 
            this.teacher_by_idBindingSource.DataMember = "Teacher_by_id";
            this.teacher_by_idBindingSource.DataSource = this.schoolDBDataSet;
            // 
            // teacher_by_idTableAdapter
            // 
            this.teacher_by_idTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.Student_by_idTableAdapter = null;
            this.tableAdapterManager.Student_SubjectTableAdapter = null;
            this.tableAdapterManager.StudentTableAdapter = null;
            this.tableAdapterManager.Subject_TeacherTableAdapter = null;
            this.tableAdapterManager.SubjectTableAdapter = null;
            this.tableAdapterManager.TeacherTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // fill_teacher_by_idToolStrip
            // 
            this.fill_teacher_by_idToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fill_teacher_by_idToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel,
            this.param1ToolStripTextBox,
            this.fill_teacher_by_idToolStripButton});
            this.fill_teacher_by_idToolStrip.Location = new System.Drawing.Point(205, 9);
            this.fill_teacher_by_idToolStrip.Name = "fill_teacher_by_idToolStrip";
            this.fill_teacher_by_idToolStrip.Size = new System.Drawing.Size(211, 25);
            this.fill_teacher_by_idToolStrip.TabIndex = 1;
            this.fill_teacher_by_idToolStrip.Text = "fill_teacher_by_idToolStrip";
            // 
            // param1ToolStripLabel
            // 
            this.param1ToolStripLabel.Name = "param1ToolStripLabel";
            this.param1ToolStripLabel.Size = new System.Drawing.Size(63, 22);
            this.param1ToolStripLabel.Text = "Teacher Id:";
            // 
            // param1ToolStripTextBox
            // 
            this.param1ToolStripTextBox.Name = "param1ToolStripTextBox";
            this.param1ToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fill_teacher_by_idToolStripButton
            // 
            this.fill_teacher_by_idToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fill_teacher_by_idToolStripButton.Name = "fill_teacher_by_idToolStripButton";
            this.fill_teacher_by_idToolStripButton.Size = new System.Drawing.Size(34, 22);
            this.fill_teacher_by_idToolStripButton.Text = "Find";
            this.fill_teacher_by_idToolStripButton.Click += new System.EventHandler(this.fill_teacher_by_idToolStripButton_Click);
            // 
            // teacher_by_idDataGridView
            // 
            this.teacher_by_idDataGridView.AllowUserToAddRows = false;
            this.teacher_by_idDataGridView.AllowUserToDeleteRows = false;
            this.teacher_by_idDataGridView.AutoGenerateColumns = false;
            this.teacher_by_idDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.teacher_by_idDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.teacher_by_idDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewCheckBoxColumn1});
            this.teacher_by_idDataGridView.DataSource = this.teacher_by_idBindingSource;
            this.teacher_by_idDataGridView.Location = new System.Drawing.Point(30, 67);
            this.teacher_by_idDataGridView.Name = "teacher_by_idDataGridView";
            this.teacher_by_idDataGridView.ReadOnly = true;
            this.teacher_by_idDataGridView.Size = new System.Drawing.Size(649, 220);
            this.teacher_by_idDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TeacherId";
            this.dataGridViewTextBoxColumn1.HeaderText = "TeacherId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TeacherName";
            this.dataGridViewTextBoxColumn2.HeaderText = "TeacherName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TeacherTel";
            this.dataGridViewTextBoxColumn3.HeaderText = "TeacherTel";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "TeacherAddress";
            this.dataGridViewTextBoxColumn4.HeaderText = "TeacherAddress";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TeacherEmail";
            this.dataGridViewTextBoxColumn5.HeaderText = "TeacherEmail";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "TeacherGender";
            this.dataGridViewCheckBoxColumn1.HeaderText = "TeacherGender";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // student_by_teacherIdBindingSource
            // 
            this.student_by_teacherIdBindingSource.DataSource = this.schoolDBDataSet;
            this.student_by_teacherIdBindingSource.Position = 0;
            // 
            // student_by_teacherIdTableAdapter
            // 
            this.student_by_teacherIdTableAdapter.ClearBeforeFill = true;
            // 
            // student_by_teacherIdBindingSource1
            // 
            this.student_by_teacherIdBindingSource1.DataSource = this.schoolDBDataSet;
            this.student_by_teacherIdBindingSource1.Position = 0;
            // 
            // student_by_teacherIdBindingSource2
            // 
            this.student_by_teacherIdBindingSource2.DataSource = this.schoolDBDataSet;
            this.student_by_teacherIdBindingSource2.Position = 0;
            // 
            // student_by_teacherIdBindingSource3
            // 
            this.student_by_teacherIdBindingSource3.DataSource = this.schoolDBDataSet;
            this.student_by_teacherIdBindingSource3.Position = 0;
            // 
            // student_by_teacherIdBindingSource4
            // 
            this.student_by_teacherIdBindingSource4.DataSource = this.schoolDBDataSet;
            this.student_by_teacherIdBindingSource4.Position = 0;
            // 
            // student_by_teacherIdBindingSource5
            // 
            this.student_by_teacherIdBindingSource5.DataMember = "Student_by_teacherId";
            this.student_by_teacherIdBindingSource5.DataSource = this.schoolDBDataSet;
            // 
            // student_by_teacherIdDataGridView
            // 
            this.student_by_teacherIdDataGridView.AllowUserToAddRows = false;
            this.student_by_teacherIdDataGridView.AllowUserToDeleteRows = false;
            this.student_by_teacherIdDataGridView.AutoGenerateColumns = false;
            this.student_by_teacherIdDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.student_by_teacherIdDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.student_by_teacherIdDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewCheckBoxColumn2});
            this.student_by_teacherIdDataGridView.DataSource = this.student_by_teacherIdBindingSource5;
            this.student_by_teacherIdDataGridView.Location = new System.Drawing.Point(30, 337);
            this.student_by_teacherIdDataGridView.Name = "student_by_teacherIdDataGridView";
            this.student_by_teacherIdDataGridView.ReadOnly = true;
            this.student_by_teacherIdDataGridView.Size = new System.Drawing.Size(649, 220);
            this.student_by_teacherIdDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "StudentId";
            this.dataGridViewTextBoxColumn6.HeaderText = "StudentId";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "StudentName";
            this.dataGridViewTextBoxColumn7.HeaderText = "StudentName";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "StudentTel";
            this.dataGridViewTextBoxColumn8.HeaderText = "StudentTel";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "StudentAddress";
            this.dataGridViewTextBoxColumn9.HeaderText = "StudentAddress";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "StudentEmail";
            this.dataGridViewTextBoxColumn10.HeaderText = "StudentEmail";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "StudentGender";
            this.dataGridViewCheckBoxColumn2.HeaderText = "StudentGender";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Teacher Information:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Teacher\'s Students:";
            // 
            // frmTeacher_Students
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(709, 565);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.student_by_teacherIdDataGridView);
            this.Controls.Add(this.teacher_by_idDataGridView);
            this.Controls.Add(this.fill_teacher_by_idToolStrip);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTeacher_Students";
            this.Text = "Teacher_Students";
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idBindingSource)).EndInit();
            this.fill_teacher_by_idToolStrip.ResumeLayout(false);
            this.fill_teacher_by_idToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_by_teacherIdDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDBDataSet schoolDBDataSet;
        private System.Windows.Forms.BindingSource teacher_by_idBindingSource;
        private SchoolDBDataSetTableAdapters.Teacher_by_idTableAdapter teacher_by_idTableAdapter;
        private SchoolDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ToolStrip fill_teacher_by_idToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fill_teacher_by_idToolStripButton;
        private System.Windows.Forms.DataGridView teacher_by_idDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.BindingSource student_by_teacherIdBindingSource;
        private SchoolDBDataSetTableAdapters.Student_by_teacherIdTableAdapter student_by_teacherIdTableAdapter;
        private System.Windows.Forms.BindingSource student_by_teacherIdBindingSource1;
        private System.Windows.Forms.BindingSource student_by_teacherIdBindingSource2;
        private System.Windows.Forms.BindingSource student_by_teacherIdBindingSource3;
        private System.Windows.Forms.BindingSource student_by_teacherIdBindingSource4;
        private System.Windows.Forms.BindingSource student_by_teacherIdBindingSource5;
        private System.Windows.Forms.DataGridView student_by_teacherIdDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}