﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Project
{
    public partial class frmStudent : Form
    {
        public frmStudent()
        {
            InitializeComponent();
        }

        private void studentBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.studentBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.schoolDBDataSet);

        }

        private void fmStudent_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDBDataSet.Student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.schoolDBDataSet.Student);
        }

        private void studentGenderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.studentGenderCheckBox.CheckState == CheckState.Checked)
                studentGenderCheckBox.Text = "Male";
            else if (this.studentGenderCheckBox.CheckState == CheckState.Unchecked)
                studentGenderCheckBox.Text = "Female";
            else
                studentGenderCheckBox.Text = "?";
        }

      
    }
}
