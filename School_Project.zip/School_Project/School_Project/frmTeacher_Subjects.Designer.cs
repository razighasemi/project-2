﻿namespace School_Project
{
    partial class frmTeacher_Subjects
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.schoolDBDataSet = new School_Project.SchoolDBDataSet();
            this.teacher_by_idBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacher_by_idTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.Teacher_by_idTableAdapter();
            this.tableAdapterManager = new School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager();
            this.fill_teacher_by_idToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fill_teacher_by_idToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.teacher_by_idDataGridView = new System.Windows.Forms.DataGridView();
            this.teacherAndSubjectsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.teacherAndSubjectsTableAdapter = new School_Project.SchoolDBDataSetTableAdapters.TeacherAndSubjectsTableAdapter();
            this.teacherAndSubjectsDataGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idBindingSource)).BeginInit();
            this.fill_teacher_by_idToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAndSubjectsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAndSubjectsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // schoolDBDataSet
            // 
            this.schoolDBDataSet.DataSetName = "SchoolDBDataSet";
            this.schoolDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // teacher_by_idBindingSource
            // 
            this.teacher_by_idBindingSource.DataMember = "Teacher_by_id";
            this.teacher_by_idBindingSource.DataSource = this.schoolDBDataSet;
            // 
            // teacher_by_idTableAdapter
            // 
            this.teacher_by_idTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.Student_by_idTableAdapter = null;
            this.tableAdapterManager.Student_SubjectTableAdapter = null;
            this.tableAdapterManager.StudentTableAdapter = null;
            this.tableAdapterManager.Subject_TeacherTableAdapter = null;
            this.tableAdapterManager.SubjectTableAdapter = null;
            this.tableAdapterManager.TeacherTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = School_Project.SchoolDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // fill_teacher_by_idToolStrip
            // 
            this.fill_teacher_by_idToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fill_teacher_by_idToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel,
            this.toolStripSeparator2,
            this.param1ToolStripTextBox,
            this.toolStripSeparator1,
            this.fill_teacher_by_idToolStripButton});
            this.fill_teacher_by_idToolStrip.Location = new System.Drawing.Point(192, 35);
            this.fill_teacher_by_idToolStrip.Name = "fill_teacher_by_idToolStrip";
            this.fill_teacher_by_idToolStrip.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.fill_teacher_by_idToolStrip.Size = new System.Drawing.Size(301, 28);
            this.fill_teacher_by_idToolStrip.TabIndex = 1;
            this.fill_teacher_by_idToolStrip.Text = "fill_teacher_by_idToolStrip";
            // 
            // param1ToolStripLabel
            // 
            this.param1ToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.param1ToolStripLabel.Name = "param1ToolStripLabel";
            this.param1ToolStripLabel.Size = new System.Drawing.Size(82, 22);
            this.param1ToolStripLabel.Text = "Teacher Id:";
            // 
            // param1ToolStripTextBox
            // 
            this.param1ToolStripTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.param1ToolStripTextBox.Name = "param1ToolStripTextBox";
            this.param1ToolStripTextBox.Size = new System.Drawing.Size(148, 28);
            // 
            // fill_teacher_by_idToolStripButton
            // 
            this.fill_teacher_by_idToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fill_teacher_by_idToolStripButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fill_teacher_by_idToolStripButton.Name = "fill_teacher_by_idToolStripButton";
            this.fill_teacher_by_idToolStripButton.Size = new System.Drawing.Size(44, 25);
            this.fill_teacher_by_idToolStripButton.Text = "Find";
            this.fill_teacher_by_idToolStripButton.Click += new System.EventHandler(this.fill_teacher_by_idToolStripButton_Click);
            // 
            // teacher_by_idDataGridView
            // 
            this.teacher_by_idDataGridView.AllowUserToAddRows = false;
            this.teacher_by_idDataGridView.AllowUserToDeleteRows = false;
            this.teacher_by_idDataGridView.AutoGenerateColumns = false;
            this.teacher_by_idDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.teacher_by_idDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.teacher_by_idDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewCheckBoxColumn1});
            this.teacher_by_idDataGridView.DataSource = this.teacher_by_idBindingSource;
            this.teacher_by_idDataGridView.Location = new System.Drawing.Point(14, 103);
            this.teacher_by_idDataGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.teacher_by_idDataGridView.Name = "teacher_by_idDataGridView";
            this.teacher_by_idDataGridView.ReadOnly = true;
            this.teacher_by_idDataGridView.Size = new System.Drawing.Size(807, 95);
            this.teacher_by_idDataGridView.TabIndex = 2;
            // 
            // teacherAndSubjectsBindingSource1
            // 
            this.teacherAndSubjectsBindingSource1.DataMember = "TeacherAndSubjects";
            this.teacherAndSubjectsBindingSource1.DataSource = this.schoolDBDataSet;
            // 
            // teacherAndSubjectsTableAdapter
            // 
            this.teacherAndSubjectsTableAdapter.ClearBeforeFill = true;
            // 
            // teacherAndSubjectsDataGridView
            // 
            this.teacherAndSubjectsDataGridView.AllowUserToAddRows = false;
            this.teacherAndSubjectsDataGridView.AllowUserToDeleteRows = false;
            this.teacherAndSubjectsDataGridView.AutoGenerateColumns = false;
            this.teacherAndSubjectsDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.teacherAndSubjectsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.teacherAndSubjectsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.teacherAndSubjectsDataGridView.DataSource = this.teacherAndSubjectsBindingSource1;
            this.teacherAndSubjectsDataGridView.Location = new System.Drawing.Point(138, 256);
            this.teacherAndSubjectsDataGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.teacherAndSubjectsDataGridView.Name = "teacherAndSubjectsDataGridView";
            this.teacherAndSubjectsDataGridView.ReadOnly = true;
            this.teacherAndSubjectsDataGridView.Size = new System.Drawing.Size(549, 227);
            this.teacherAndSubjectsDataGridView.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Teacher Information:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Teacher\'s Subjects:";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 28);
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "SubjectId";
            this.dataGridViewTextBoxColumn6.HeaderText = "SubjectId";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "SubjectName";
            this.dataGridViewTextBoxColumn7.HeaderText = "SubjectName";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "SubjectUnit";
            this.dataGridViewTextBoxColumn8.HeaderText = "SubjectUnit";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "SubjectDescription";
            this.dataGridViewTextBoxColumn9.HeaderText = "SubjectDescription";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 200;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TeacherId";
            this.dataGridViewTextBoxColumn1.HeaderText = "TeacherId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TeacherName";
            this.dataGridViewTextBoxColumn2.HeaderText = "TeacherName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TeacherTel";
            this.dataGridViewTextBoxColumn3.HeaderText = "TeacherTel";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "TeacherAddress";
            this.dataGridViewTextBoxColumn4.HeaderText = "TeacherAddress";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TeacherEmail";
            this.dataGridViewTextBoxColumn5.HeaderText = "TeacherEmail";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "TeacherGender";
            this.dataGridViewCheckBoxColumn1.HeaderText = "TeacherGender";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Width = 150;
            // 
            // frmTeacher_Subjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(834, 498);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.teacherAndSubjectsDataGridView);
            this.Controls.Add(this.teacher_by_idDataGridView);
            this.Controls.Add(this.fill_teacher_by_idToolStrip);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTeacher_Subjects";
            this.Text = "frmTeacher_Subjects";
            ((System.ComponentModel.ISupportInitialize)(this.schoolDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idBindingSource)).EndInit();
            this.fill_teacher_by_idToolStrip.ResumeLayout(false);
            this.fill_teacher_by_idToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacher_by_idDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAndSubjectsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAndSubjectsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDBDataSet schoolDBDataSet;
        private System.Windows.Forms.BindingSource teacher_by_idBindingSource;
        private SchoolDBDataSetTableAdapters.Teacher_by_idTableAdapter teacher_by_idTableAdapter;
        private SchoolDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ToolStrip fill_teacher_by_idToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fill_teacher_by_idToolStripButton;
        private System.Windows.Forms.DataGridView teacher_by_idDataGridView;
        private System.Windows.Forms.BindingSource teacherAndSubjectsBindingSource1;
        private SchoolDBDataSetTableAdapters.TeacherAndSubjectsTableAdapter teacherAndSubjectsTableAdapter;
        private System.Windows.Forms.DataGridView teacherAndSubjectsDataGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
    }
}